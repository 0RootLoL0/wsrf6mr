package com.example.popovgym.pojo;

public class LogoutUser {
    String username;

    public LogoutUser(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
