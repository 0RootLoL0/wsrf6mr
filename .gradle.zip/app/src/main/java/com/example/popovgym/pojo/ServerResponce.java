package com.example.popovgym.pojo;

public class ServerResponce {
    private Notice notice;
    public class Notice{
        private String answer;
        private int token;

        public Notice(String answer) {
            this.answer = answer;
        }

        public Notice(int token) {
            this.token = token;
        }

        public String getAnswer() {
            return answer;
        }

        public void setAnswer(String answer) {
            this.answer = answer;
        }

        public int getToken() {
            return token;
        }

        public void setToken(int token) {
            this.token = token;
        }
    }

    public Notice getNotice() {
        return notice;
    }

    public void setNotice(Notice notice) {
        this.notice = notice;
    }
}
